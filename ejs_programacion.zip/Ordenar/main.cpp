#include <iostream>
#include "negocio.h"
#include "granja.h"
#include "numericos.h"
#include "geometricos.h"
#include "otros.h"
#include "arreglos_ent.h"

using namespace std;

int menu(char** X, int n){
    int opc;
    do{
        for(int i = 0; i< n;i++){
            cout<<(i+1)<<". "<<X[i]<<endl;
        }
        cout<<"0. Salir"<<endl;
        cout<<"Ingrese opcion: ";
        cin>>opc;
        if(opc<0 || opc>n){
            cout<<"Para que te traje"<<endl;
        }
    }
    while(opc<0 || opc> n);
    return opc;
}

char** opciones(int n){
    char** X= new char*[n];
    return X;

}

void negocio(){
    double p;
    int n;
    int x;
    int y;
    cout<<"Ingrese precio: ";
    cin>>p;
    cout<<"Ingrese cantidad de productos: ";
    cin>>n;
    cout<<"Cantidad para 10%: ";
    cin>>x;
    cout<<"Cantidad para 20%: ";
    cin>>y;
    cout<<costo(p,n,x,y)<<endl;
}

void granja(){
    char** X= opciones(3);
    X[0]= "Carne china";
    X[1]= "Leche";
    X[2]="Negocio";
    int k;
    do{
    k = menu(X,3);
    switch(k){
        case 1:
            double n,m,M,x;
            cout<<"Litros leche"<<endl;
            cout<<litros_leche(n,m,M,x)<<endl;
        break;
        case 2:
            int A;
            cant_huevos(A);
        break;
        case 3:
            int Peq,Med,Gra;
            kil_esc(Peq,Med,Gra);
        break;
        case 4:
            double x1,y1;
            int p,q,s;
            cout<<cer_eco(x1,y1,p,q,s)<<endl;
        break;
        }
    }
    while(k!=0);
}

void geometricos(){
    char** X= opciones(5);
    X[0]= "Propiedades de dos rectas";
    X[1]= "Punto de interseccion entre dos rectas";
    X[2]= "Area del triangulo que circunscribe un circulo";
    X[3]= "Area y perimetro de cuadrado, pentagono, hexagono inscritos en un circulo o viceversa";
    X[4]= "Cantidad de telara�a";
    int k;
    do{
    k = menu(X,3);
    switch(k){
        case 1:
            double p1,c1,p2,c2;
            par_per(p1,c1,p2,c2);
        break;
        case 2:
            inter(p1,c1,p2,c2);
        break;
        case 3:

        break;
        case 4:

        break;
        }
    }
    while(k!=0);
}

void numericos(){
    char** X= opciones(9);
    X[0]= "Potencia";
    X[1]= "";
    X[2]= "";
    int k;
    do{
    k = menu(X,3);
    switch(k){
        case 1:
            int base, exponente;
            cout<<potencia(base, exponente);
        break;
        case 2:
            int num1, num2;
            cout<<es_divisible(num1, num2);
        break;
        case 3:
            int num;
            cout<<es_primo(num,2);
        break;
        case 4:
            int x, y;
            cout<<es_primo_relativo(x,y);
        break;
        case 5:
            int x1, x2, mul;
            cout<<es_multiplo_suma(x1, x2, mul);
        break;
        case 6:
            double coef1, coef2,coef3,r;
            cout<<eva_pol_punto(coef1,coef2,coef3,r);
        break;
        case 7:
            cout<<coef_lin_der(coef1,coef2,coef3)<<endl;
        break;
        case 8:
            cout<<eva_der_punto(coef1, coef2, coef3,r)<<endl;
        break;
        case 9:
            int a;
            cout<<es_fib(a)<<endl;
        break;
        }
    }
    while(k!=0);
}

void menu_principal(){
 char** A= opciones(5);
    A[0] = "La granja";
    A[1] = "Numericos";
    A[2] = "Geometricos";
    A[3] = "Otros";
    A[4] = "Arreglos Enteros";
    int k;
    do{
        k = menu(A,4);
    switch(k){
        case 1:
           granja();
        break;
        case 2:
            numericos();
        break;
        case 3:
            geometricos();
        break;
        case 4:
//            otros();
        break;
        case 5:
  //          arreglos();
        break;


    }
    }
    while(k!=0);
}

int main()
{
    menu_principal();

    return 0;
}
