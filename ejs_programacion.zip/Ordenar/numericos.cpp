#include "numericos.h"

int menor(int a, int b){
    if(a>=b){
        return a;
    }else{
        return b;
    }
}

int potencia(int base, int exp){
    if(exp==0 && base!=0){
        return 1;
    }else if(exp<0){
        return 1/potencia(base,exp-1)*base;
    }else{
        return potencia(base,exp-1)*base;
    }
}

bool es_divisible(int a, int b){
    return a % b == 0;
}

bool es_primo(int numero,int c){
    if(numero%c ==0 && numero!=2){
        return false;
    }else if(c>numero/2){
        return true;
    }else{
        return es_primo(numero,c+1);
    }
}

bool es_primo_relativo(int a, int b){
    int n= menor(a,b);
    int cont=0;
    for(int i=2; i<=n ;i++){
        if(a % i == 0 &&  b % i ==0 ){
            cont++;
        }
    }
    return cont == 0;
}

bool es_multiplo_suma(int a, int b, int c){
    return c%(a+b)==0;
}

double eva_pol_punto(double a, double b, double c, double x){
    return a*x*x+b*x+c;
}

double coef_lin_der(double a, double b, double c){
    return 2*a;
}

double eva_der_punto(double a, double b, double c, double x){
    return 2*a*x+b;
}

bool es_fib(int num){
    int fib0=1;
    int fib1=1;
    int fib2;
    do{
        fib2=fib1+fib0;
        fib0=fib1;
        fib1=fib2;
    }while(num>fib2);
    return num == fib2;
}

double raiz(double a){
    double Xo;
    double Xi = a;
    do{
        Xo = Xi;
        Xi = 0.5 * (Xo + a / Xo);
    }while(valor_absoluto(Xo - Xi) >= 1e-4);
    return 0.5 * (Xi + a / Xi);
};

double valor_absoluto(double a){
    if(a>0){
        return a;
    }else{
        return -a;
    }
}
