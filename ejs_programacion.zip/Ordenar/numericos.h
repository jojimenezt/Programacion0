#ifndef NUMERICOS_H_INCLUDED
#define NUMERICOS_H_INCLUDED

int potencia(int base, int potencia);

bool es_divisible(int a, int b);

bool es_primo(int numero,int c);

bool es_primo_relativo(int a, int b);

bool es_multiplo_suma(int a, int b, int c);

double eva_pol_punto(double a, double b, double c, double x);

double coef_lin_der(double a, double b, double c);

double eva_der_punto(double a, double b, double c, double x);

bool es_fib(int num);

int menor(int a, int b);

double valor_absoluto(double a);

double raiz(double a);

#endif // NUMERICOS_H_INCLUDED
