#ifndef GRANJA_H_INCLUDED
#define GRANJA_H_INCLUDED

#include "granja.h"

double litros_leche(double n, double m, double M, double x);

int cant_huevos(int A);

int kil_esc(int P, int M, int G);

char* cer_eco(double m, double n, int p, int q, int s);


#endif // GRANJA_H_INCLUDED
