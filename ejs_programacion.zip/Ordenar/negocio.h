#ifndef NEGOCIO_H_INCLUDED
#define NEGOCIO_H_INCLUDED

double costo(double p, int n, int x, int y);

#endif // NEGOCIO_H_INCLUDED
